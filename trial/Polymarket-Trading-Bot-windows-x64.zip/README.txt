Polymarket-Trading-Bot — Windows x64 (trial through September 30, 2027)
==============================================================

QUICK START
1. Unzip this folder on your PC.
2. Copy .env.sample to .env and fill in your keys.
3. Double-click "Start Polymarket-Trading-Bot.bat"

Protection: obfuscated-js-clean + pkg bytecode

NOTES
- No Node.js install required.
- Trial license expires September 30, 2027 UTC.
- Windows SmartScreen may warn on first run — choose "More info" then "Run anyway".
