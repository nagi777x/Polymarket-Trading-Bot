@echo off
cd /d "%~dp0"
if not exist ".env" (
  echo.
  echo Missing .env file.
  echo Copy .env.sample to .env in this folder and fill in your keys.
  echo.
  pause
  exit /b 1
)
"Polymarket-Trading-Bot-win-x64.exe"
echo.
pause
